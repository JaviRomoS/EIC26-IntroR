## Estrategias de Investigación Cuantitativa 2026, Universidad de Chile
## Profesor: Pablo Pérez Ahumada
## Apoyo docente: Javiera Romo Sánchez
## Ayudantes: Valentina Montecinos, Martina Buzio, Javiera Álvarez,
##            Millaray Vergara y Tomás González.

# ------------------------------------------------------------------------ #
#   CÁPSULA: INTRODUCCIÓN A R                                               #
#   Base ficticia: notas de dos cursos de un colegio                        #
#   Basada en "R para Ciencia de Datos": https://es.r4ds.hadley.nz/         #
# ------------------------------------------------------------------------ #

# Para ejecutar una línea: Ctrl + Enter (en Mac: Cmd + Enter)


# MÓDULO 1: INTERFAZ DE RSTUDIO -------------------------------------------

# Todo lo que va después de un # es un comentario: R no lo ejecuta.
# Si abrieron este script desde intro_R.Rproj, R ya sabe dónde está trabajando:
getwd()

2 + 2


# MÓDULO 2: PROGRAMACIÓN BÁSICA -------------------------------------------

## R como calculadora
10 + 5
10 - 5
10 * 5
10 / 4
2 ^ 3
(5.5 + 6.2) / 2
sqrt(16)

## Crear objetos (atajo para <- : Alt + -)
nota_mate <- 5.5
nota_leng <- 6.2
nota_mate
promedio <- (nota_mate + nota_leng) / 2
promedio

## Vectores
notas_curso <- c(5.5, 6.2, 4.8, 3.9, 6.7)
notas_curso
notas_curso + 0.5
length(notas_curso)

## Funciones
mean(notas_curso)
median(notas_curso)
max(notas_curso)
round(4.8667, 1)

## Argumentos y ayuda
round(x = 4.8667, digits = 2)
round(4.8667, 2)
seq(from = 1, to = 7, by = 0.5)
?round

## Errores comunes (descomenten y ejecuten para ver el mensaje)
# Nota_mate
# "5.5" + 1

## Prueba tú
# 1. Creen un objeto "edades" con las edades de cinco compañeros/as.
# 2. Calculen la media y la mediana de "edades".
# 3. Guarden la media en un objeto llamado "edad_promedio".
# 4. Redondeen "edad_promedio" a un decimal.
# 5. Busquen qué hace range() y pruébenla con "edades".


# MÓDULO 3: LIBRERÍAS -----------------------------------------------------

options(scipen = 999)   # desactiva la notación científica
rm(list = ls())         # limpia el entorno de trabajo (borra todos los objetos)

#install.packages("pacman") # Descarga pacman si es que no lo tienen
library("pacman")
pacman::p_load(tidyverse,  # manipulación de datos (dplyr) y gráficos (ggplot2)
               readxl,     # abrir archivos de Excel
               haven)      # trabajar con variables etiquetadas


# MÓDULO 4: BASES DE DATOS RECTANGULARES ----------------------------------

## Datos ordenados vs. desordenados
desordenada <- tribble(
  ~estudiante, ~mate_2A, ~mate_2B,
  "Ana",        6.1,      NA,
  "Benja",      NA,       5.4,
  "Carla",      4.9,      NA
)
desordenada

ordenada <- tribble(
  ~estudiante, ~curso, ~nota_mate,
  "Ana",       "2°A",   6.1,
  "Benja",     "2°B",   5.4,
  "Carla",     "2°A",   4.9
)
ordenada

## Un data frame es un conjunto de vectores del mismo largo
estudiante <- c("Ana", "Benja", "Carla")
curso      <- c("2°A", "2°B", "2°A")
nota_mate  <- c(6.1, 5.4, 4.9)
mi_base <- data.frame(estudiante, curso, nota_mate)
mi_base

mi_tibble <- tibble(estudiante = c("Ana", "Benja", "Carla"),
                    curso      = c("2°A", "2°B", "2°A"),
                    nota_mate  = c(6.1, 5.4, 4.9))
mi_tibble

## Importar la base de datos
notas <- read_excel("input/notas_colegio.xlsx")
notas

## Explorar la base
dim(notas)
nrow(notas)
ncol(notas)
names(notas)
glimpse(notas)
View(notas)

## Acceder a una variable con $
notas$edad
mean(notas$edad)
table(notas$curso)

## Prueba tú
# 1. ¿Cuántas observaciones y cuántas variables tiene "notas"?
# 2. ¿Qué representa cada fila? ¿Cuál es la unidad de análisis?
# 3. Usen glimpse() y escriban qué mide cada variable.


# MÓDULO 5: NATURALEZA DE LAS VARIABLES -----------------------------------

## ¿De qué tipo es cada variable?
class(notas$genero)
class(notas$nota_matematicas)
summary(notas$edad)

## Texto
table(notas$genero)

## Lógicas
5.5 >= 4
"2°A" == "2°B"
head(notas$nota_lenguaje >= 4)

## Factores
genero_f <- factor(notas$genero)
levels(genero_f)

nivel <- c("Medio", "Bajo", "Alto", "Medio")
factor(nivel)
factor(nivel, levels = c("Bajo", "Medio", "Alto"))

## Valores perdidos (NA)
notas_ejemplo <- c(5.5, NA, 6.1, 4.8)
mean(notas_ejemplo)
mean(notas_ejemplo, na.rm = TRUE)
is.na(notas_ejemplo)

## El problema de los códigos 888 (No rindió) y 999 (Sin información)
mean(notas$nota_matematicas)   # ¡no tiene sentido!
mean(notas$nota_lenguaje)
table(notas$nota_matematicas %in% c(888, 999))

## Variables etiquetadas (haven_labelled), como en las bases de SPSS o Stata
nota_etiq <- labelled(c(5.5, 6.1, 888, 4.2, 999),
                      labels = c("No rindió" = 888, "Sin información" = 999))
nota_etiq
attr(nota_etiq, "labels")
zap_labels(nota_etiq)   # quita las etiquetas: queda el número
as_factor(nota_etiq)    # convierte a factor: queda la etiqueta

## Coerción
as.numeric("5.5")
as.character(16)
as.numeric(c("6.1", "seis"))

edades_f <- factor(c("17", "15", "16"))
as.numeric(edades_f)                 # posiciones de los niveles
as.numeric(as.character(edades_f))   # valores originales

## Prueba tú
# 1. Identifiquen el tipo y el nivel de medición de cada variable.
# 2. Conviertan "curso" en factor y revisen sus niveles.
# 3. ¿Cuántos estudiantes tienen 888 o 999 en nota_lenguaje?


# MÓDULO 6: TRANSFORMAR DATOS CON DPLYR -----------------------------------

## El pipe %>% (atajo: Ctrl + Shift + M)
round(mean(c(5.5, 6.2, 4.8)), 1)
c(5.5, 6.2, 4.8) %>% mean() %>% round(1)

## filter(): elegir filas
notas %>%
  filter(curso == "2°A")

notas %>%
  filter(curso == "2°B", genero == "Femenino") %>%
  nrow()

notas %>%
  filter(edad == 15 | edad == 17) %>%
  nrow()

notas %>%
  filter(nota_matematicas %in% c(888, 999))

## arrange(): ordenar filas
notas %>%
  arrange(nota_lenguaje)

notas %>%
  filter(nota_lenguaje <= 7) %>%
  arrange(desc(nota_lenguaje))

## select(): elegir columnas
notas %>% select(id, genero, nota_lenguaje)
notas %>% select(-edad)
notas %>% select(id, starts_with("nota_"))

## rename(): cambiar nombres (nombre_nuevo = nombre_viejo)
notas %>%
  rename(mate = nota_matematicas,
         leng = nota_lenguaje)

## mutate(): recodificar 888 y 999 a NA (¡y guardar el resultado!)
notas <- notas %>%
  mutate(nota_matematicas = if_else(nota_matematicas %in% c(888, 999), NA, nota_matematicas),
         nota_lenguaje    = if_else(nota_lenguaje    %in% c(888, 999), NA, nota_lenguaje))

summary(notas$nota_matematicas)

## mutate(): crear variables nuevas
notas <- notas %>%
  mutate(promedio     = (nota_matematicas + nota_lenguaje) / 2,
         aprueba_mate = if_else(nota_matematicas >= 4, "Aprueba", "Reprueba"),
         genero       = factor(genero))

## mutate() con case_when()
notas <- notas %>%
  mutate(tramo_lenguaje = case_when(nota_lenguaje <  4   ~ "Insuficiente",
                                    nota_lenguaje <  5.5 ~ "Suficiente",
                                    nota_lenguaje >= 5.5 ~ "Destacado"))

table(notas$tramo_lenguaje, useNA = "ifany")

## summarise(): resumir
notas %>%
  summarise(n          = n(),
            media_mate = mean(nota_matematicas, na.rm = TRUE),
            media_leng = mean(nota_lenguaje, na.rm = TRUE),
            de_leng    = sd(nota_lenguaje, na.rm = TRUE))

## group_by() + summarise(): resumir por grupos
notas %>%
  group_by(genero) %>%
  summarise(n          = n(),
            media_mate = mean(nota_matematicas, na.rm = TRUE),
            media_leng = mean(nota_lenguaje, na.rm = TRUE))

notas %>%
  group_by(curso, genero) %>%
  summarise(media_mate = round(mean(nota_matematicas, na.rm = TRUE), 2),
            media_leng = round(mean(nota_lenguaje, na.rm = TRUE), 2),
            .groups = "drop")

## count(): contar casos
notas %>%
  count(genero, aprueba_mate)

notas %>%
  filter(!is.na(aprueba_mate)) %>%
  group_by(genero) %>%
  summarise(pct_aprueba = mean(aprueba_mate == "Aprueba") * 100)

## Todo junto: ¿las brechas de género son iguales en ambos cursos?
brechas <- notas %>%
  filter(!is.na(nota_matematicas), !is.na(nota_lenguaje)) %>%
  group_by(curso, genero) %>%
  summarise(n = n(),
            mate = mean(nota_matematicas),
            leng = mean(nota_lenguaje),
            .groups = "drop") %>%
  mutate(diferencia = round(mate - leng, 2)) %>%
  arrange(curso, desc(diferencia))

brechas

## Guardar resultados en output/
write_csv(brechas, "output/brechas_genero.csv")
saveRDS(notas, "output/notas_limpia.rds")

## Prueba tú
# 1. Filtren a los estudiantes del 2°B con más de 6 en Lenguaje. ¿Cuántos son?
# 2. Creen la variable "aprueba_leng" (Aprueba / Reprueba).
# 3. Calculen el porcentaje de aprobación en Lenguaje por género.
# 4. Calculen la nota promedio de Matemáticas por edad.
# 5. Guarden su tabla final en output/ con write_csv().
